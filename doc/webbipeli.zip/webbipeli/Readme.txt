Controllit:
W = ylös
S = alas
C = ammu
alt + f4 = poistu pelistä

Kristian T.